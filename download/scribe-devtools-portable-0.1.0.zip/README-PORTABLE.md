# browser-inspector 0.1.0 — portable

Wymagania: Node >= 22 i systemowy Chrome albo Edge. Bez `npm install`, bez builda.

```
bi help                      # Windows: bi.cmd, POSIX: ./bi
node packages/browser-inspector/bin/bi.mjs help
```

Zawartość: `packages/browser-inspector` (bin, src, templates, fixtures), `node_modules/playwright-core` 1.62.1,
marker `packages/browser-inspector/PORTABLE` (keeper pomija stempel mtime źródeł). Dokumentacja: README.md w repozytorium.
