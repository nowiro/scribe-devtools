@echo off
node "%~dp0packages\browser-inspector\bin\bi.mjs" %*
